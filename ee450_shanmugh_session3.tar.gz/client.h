#define CLIENT1 "32676"
#define CLIENT2 "33676"
#define DIR_SERVER "31676"
#define MAXDATASIZE 100
#define BACKLOG 10

void *get_in_addr(struct sockaddr *);
int phase2();
int phase3();

